const express = require('express');
const path = require('path');

var app = express();
var server = require('http').Server(app);
app.use(express.static('public'));
const io = require('socket.io')(server, {
  path: '/room',
  serveClient: false,
  // below are engine.IO options
  pingInterval: 10000,
  pingTimeout: 5000,
  cookie: false
});
server.listen(3000);

let roomList = new Map();
roomList.set('777777',new Set());
roomList.set('123456',new Set());



io.on('connection', function (socket) {
  // 获取请求建立socket连接的url
  // 如: http://localhost:3000/room/room_1, roomID为room_1
  const url = socket.handshake.url;
  const splited = url.split('/');
  const roomID = splited[splited.length - 2];   // 获取房间ID
  const currentRoom = roomList.get(roomID);
  let user = '';
  
  
  socket.on('join', function (userName) {
    user = userName;
    // 将用户昵称加入房间名单中    
    if (!roomList.has(roomID)) {
       console.log("用户访问错误房间");
    }else{
      currentRoom.add(user);  
      socket.join(roomID); 
      // 通知房间内人员
      
      io.to(roomID).emit('sys', JSON.stringify({
        uname:user,
        utext:user+'加入了房间'
      }));  
      console.log(user + '加入了' + roomID);
    }
  });

  socket.on('leave', function () {
    socket.emit('disconnect');
  });

  socket.on('disconnect', function () {
    curreutestntRoom.delete(user);
    socket.leave(roomID);    // 退出房间
    io.to(roomID).emit('sys', user + '退出了房间', roomList[roomID]);
    console.log(user + '退出了' + roomID);
  });

  // 接收用户消息,发送相应的房间
  socket.on('message', function (msg) {
    console.log(msg)
    if (!currentRoom.has(user)) return false;
    io.to(roomID).emit('message', JSON.stringify({
      uname:user,
      utext:msg
    }));
  });

});
